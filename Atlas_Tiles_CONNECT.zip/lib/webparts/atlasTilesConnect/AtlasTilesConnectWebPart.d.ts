import { IPropertyFieldGroupOrPerson } from "@pnp/spfx-property-controls/lib/PropertyFieldPeoplePicker";
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart, WebPartContext } from '@microsoft/sp-webpart-base';
export interface IAtlasTilesConnectWebPartProps {
    description: string;
    ImageURL: string;
    Hyperlink: string;
    TargetAudience: string;
    people: IPropertyFieldGroupOrPerson[];
    context: WebPartContext;
}
export default class AtlasTilesConnectWebPart extends BaseClientSideWebPart<IAtlasTilesConnectWebPartProps> {
    render(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=AtlasTilesConnectWebPart.d.ts.map