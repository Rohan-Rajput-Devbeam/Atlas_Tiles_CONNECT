declare const styles: {
    g_b_50a7110f: string;
    tileImage: string;
    MainContainer: string;
    callToAction: string;
    arrow: string;
    containermain: string;
    description: string;
    ImageURL: string;
    button: string;
    label: string;
};
export default styles;
//# sourceMappingURL=AtlasTilesConnectWebPart.module.scss.d.ts.map