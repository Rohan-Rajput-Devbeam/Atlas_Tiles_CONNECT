/* tslint:disable */
require("./AtlasTilesConnectWebPart.module.css");
const styles = {
  g_b_50a7110f: 'g_b_50a7110f_46f515fe',
  tileImage: 'tileImage_46f515fe',
  MainContainer: 'MainContainer_46f515fe',
  callToAction: 'callToAction_46f515fe',
  blue: 'blue_46f515fe',
  arrow: 'arrow_46f515fe',
  containermain: 'containermain_46f515fe',
  description: 'description_46f515fe',
  ImageURL: 'ImageURL_46f515fe',
  button: 'button_46f515fe',
  label: 'label_46f515fe'
};

export default styles;
/* tslint:enable */