/* tslint:disable */
require("./AtlasTilesConnectWebPart.module.css");
const styles = {
  g_b_50a7110f: 'g_b_50a7110f_3f922cc8',
  tileImage: 'tileImage_3f922cc8',
  MainContainer: 'MainContainer_3f922cc8',
  callToAction: 'callToAction_3f922cc8',
  arrow: 'arrow_3f922cc8',
  containermain: 'containermain_3f922cc8',
  description: 'description_3f922cc8',
  ImageURL: 'ImageURL_3f922cc8',
  button: 'button_3f922cc8',
  label: 'label_3f922cc8'
};

export default styles;
/* tslint:enable */