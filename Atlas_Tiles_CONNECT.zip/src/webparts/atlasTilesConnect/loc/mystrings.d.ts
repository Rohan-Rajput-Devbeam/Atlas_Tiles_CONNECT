declare interface IAtlasTilesConnectWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  PropertyPaneDescription: string;
 BasicGroupName1: string;
  ImageURLFieldLabel: string;
 BasicGroupName2: string;
  Hyperlinklabel: string;
  people:IPropertyFieldGroupOrPerson[];
  
}

declare module 'AtlasTilesConnectWebPartStrings' {
  const strings: IAtlasTilesConnectWebPartStrings;
  export = strings;
}
