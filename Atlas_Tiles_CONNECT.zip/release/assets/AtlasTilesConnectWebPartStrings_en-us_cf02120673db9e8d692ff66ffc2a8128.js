define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "WebPart Properties",
    "DescriptionFieldLabel": "Title Text",
    "BasicGroupName1": "ImageURL",
    "ImageURLFieldLabel": "ImageURL",
    "BasicGroupName2": "Hyperlink",
    "Hyperlinklabel": "Hyperlink",
  }
});